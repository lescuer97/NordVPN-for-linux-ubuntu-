# NordVPN-for-linux-ubuntu-
Repository of scripts to install and run NordVPN with one script

Run this 3 commands: 

1- wget "https://raw.githubusercontent.com/lescuer97/NordVPN-for-linux-ubuntu-/master/install.sh"

2-  chmod +x install.sh  

3- ./install.sh

The script will download and install NordVPN and the special scripts for running diferent servers with this specifications:

Cybersec: on

Protocol: tcp

offuscated:on 
